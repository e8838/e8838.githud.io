
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar as CalendarIcon, Plus, Trash2, Clock, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const CalendarPage = () => {
  const [events, setEvents] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('tarea');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const { toast } = useToast();

  // Load events from localStorage on component mount
  useEffect(() => {
    const savedEvents = localStorage.getItem('jaiygo-events');
    if (savedEvents) {
      setEvents(JSON.parse(savedEvents));
    }
  }, []);

  // Save events to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('jaiygo-events', JSON.stringify(events));
  }, [events]);

  const handleAddEvent = (e) => {
    e.preventDefault();
    
    if (!title.trim() || !date) {
      toast({
        title: "Error",
        description: "El título y la fecha son obligatorios",
        variant: "destructive",
      });
      return;
    }
    
    const newEvent = {
      id: Date.now(),
      title: title.trim(),
      date,
      time,
      description,
      category,
      completed: false,
    };
    
    setEvents([...events, newEvent]);
    resetForm();
    setShowForm(false);
    
    toast({
      title: "Evento añadido",
      description: "El evento ha sido añadido a tu agenda",
    });
  };

  const handleDeleteEvent = (id) => {
    const updatedEvents = events.filter(event => event.id !== id);
    setEvents(updatedEvents);
    
    toast({
      title: "Evento eliminado",
      description: "El evento ha sido eliminado de tu agenda",
    });
  };

  const handleToggleComplete = (id) => {
    const updatedEvents = events.map(event => 
      event.id === id ? { ...event, completed: !event.completed } : event
    );
    setEvents(updatedEvents);
  };

  const resetForm = () => {
    setTitle('');
    setDate('');
    setTime('');
    setDescription('');
    setCategory('tarea');
  };

  const handleCancel = () => {
    resetForm();
    setShowForm(false);
  };

  const handleDateChange = (dateString) => {
    setSelectedDate(new Date(dateString));
  };

  const formatDate = (dateString) => {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'tarea':
        return 'bg-blue-100 text-blue-800';
      case 'examen':
        return 'bg-red-100 text-red-800';
      case 'proyecto':
        return 'bg-green-100 text-green-800';
      case 'reunion':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'tarea':
        return <Tag className="h-4 w-4" />;
      case 'examen':
        return <CalendarIcon className="h-4 w-4" />;
      case 'proyecto':
        return <Tag className="h-4 w-4" />;
      case 'reunion':
        return <Clock className="h-4 w-4" />;
      default:
        return <Tag className="h-4 w-4" />;
    }
  };

  // Filter events for the selected date
  const selectedDateString = selectedDate.toISOString().split('T')[0];
  const eventsForSelectedDate = events.filter(event => event.date === selectedDateString);

  // Get all unique dates that have events
  const eventDates = [...new Set(events.map(event => event.date))];

  // Get current date in YYYY-MM-DD format
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Mi Agenda</h1>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" /> Nuevo Evento
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Calendar Section */}
        <div className="md:col-span-1 bg-white rounded-lg border p-4">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <CalendarIcon className="mr-2 h-5 w-5 text-primary" /> Calendario
          </h2>
          
          <div className="mb-4">
            <input
              type="date"
              className="w-full p-2 border rounded-md"
              value={selectedDateString}
              onChange={(e) => handleDateChange(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <h3 className="font-medium text-gray-700">Fechas con eventos:</h3>
            {eventDates.length > 0 ? (
              <div className="space-y-1">
                {eventDates.sort().map(dateString => (
                  <button
                    key={dateString}
                    className={`w-full text-left px-3 py-2 rounded-md transition-colors ${
                      dateString === selectedDateString
                        ? 'bg-primary text-white'
                        : dateString === today
                          ? 'bg-yellow-50 hover:bg-yellow-100'
                          : 'hover:bg-gray-100'
                    }`}
                    onClick={() => handleDateChange(dateString)}
                  >
                    <div className="flex justify-between items-center">
                      <span>{formatDate(dateString)}</span>
                      <span className="text-sm bg-white/20 px-2 py-0.5 rounded-full">
                        {events.filter(e => e.date === dateString).length}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">No hay eventos programados</p>
            )}
          </div>
        </div>

        {/* Events List Section */}
        <div className="md:col-span-2">
          {showForm ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg border p-6"
            >
              <h2 className="text-xl font-semibold mb-4">Añadir Nuevo Evento</h2>
              
              <form onSubmit={handleAddEvent} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Título *
                  </label>
                  <input
                    type="text"
                    className="w-full p-2 border rounded-md"
                    placeholder="Título del evento"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Fecha *
                    </label>
                    <input
                      type="date"
                      className="w-full p-2 border rounded-md"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Hora
                    </label>
                    <input
                      type="time"
                      className="w-full p-2 border rounded-md"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Descripción
                  </label>
                  <textarea
                    className="w-full p-2 border rounded-md"
                    placeholder="Descripción del evento"
                    rows="3"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Categoría
                  </label>
                  <select
                    className="w-full p-2 border rounded-md"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    <option value="tarea">Tarea</option>
                    <option value="examen">Examen</option>
                    <option value="proyecto">Proyecto</option>
                    <option value="reunion">Reunión</option>
                  </select>
                </div>
                
                <div className="flex justify-end space-x-3 pt-2">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    Guardar Evento
                  </Button>
                </div>
              </form>
            </motion.div>
          ) : (
            <div className="bg-white rounded-lg border p-6">
              <h2 className="text-xl font-semibold mb-4">
                Eventos para {formatDate(selectedDateString)}
              </h2>
              
              {eventsForSelectedDate.length === 0 ? (
                <div className="text-center py-10 bg-gray-50 rounded-lg">
                  <CalendarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No hay eventos para esta fecha</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => {
                      setDate(selectedDateString);
                      setShowForm(true);
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" /> Añadir Evento
                  </Button>
                </div>
              ) : (
                <motion.div 
                  className="space-y-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ staggerChildren: 0.1 }}
                >
                  {eventsForSelectedDate.map((event) => (
                    <motion.div
                      key={event.id}
                      className={`p-4 rounded-lg border ${event.completed ? 'bg-gray-50' : 'bg-white'}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <input
                            type="checkbox"
                            className="mt-1 h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                            checked={event.completed}
                            onChange={() => handleToggleComplete(event.id)}
                          />
                          <div>
                            <h3 className={`font-medium ${event.completed ? 'line-through text-gray-500' : ''}`}>
                              {event.title}
                            </h3>
                            
                            <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                              {event.time && (
                                <span className="flex items-center">
                                  <Clock className="mr-1 h-4 w-4" /> {event.time}
                                </span>
                              )}
                              
                              <span className={`flex items-center px-2 py-0.5 rounded-full text-xs ${getCategoryColor(event.category)}`}>
                                {getCategoryIcon(event.category)}
                                <span className="ml-1 capitalize">{event.category}</span>
                              </span>
                            </div>
                            
                            {event.description && (
                              <p className="mt-2 text-sm text-gray-600">{event.description}</p>
                            )}
                          </div>
                        </div>
                        
                        <button
                          className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-gray-100"
                          onClick={() => handleDeleteEvent(event.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CalendarPage;
