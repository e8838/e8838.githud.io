
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save, Search, X, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const NotesPage = () => {
  const [notes, setNotes] = useState([]);
  const [activeNote, setActiveNote] = useState(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();

  // Load notes from localStorage on component mount
  useEffect(() => {
    const savedNotes = localStorage.getItem('jaiygo-notes');
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
  }, []);

  // Save notes to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('jaiygo-notes', JSON.stringify(notes));
  }, [notes]);

  const handleNewNote = () => {
    setActiveNote(null);
    setTitle('');
    setContent('');
    setIsEditing(true);
  };

  const handleSaveNote = () => {
    if (!title.trim()) {
      toast({
        title: "Error",
        description: "El título no puede estar vacío",
        variant: "destructive",
      });
      return;
    }

    if (activeNote === null) {
      // Create new note
      const newNote = {
        id: Date.now(),
        title: title.trim(),
        content,
        date: new Date().toISOString(),
      };
      setNotes([newNote, ...notes]);
      toast({
        title: "Nota creada",
        description: "Tu nota ha sido guardada correctamente",
      });
    } else {
      // Update existing note
      const updatedNotes = notes.map(note => 
        note.id === activeNote.id 
          ? { ...note, title: title.trim(), content, date: new Date().toISOString() } 
          : note
      );
      setNotes(updatedNotes);
      toast({
        title: "Nota actualizada",
        description: "Los cambios han sido guardados",
      });
    }
    
    setIsEditing(false);
  };

  const handleDeleteNote = (id) => {
    const updatedNotes = notes.filter(note => note.id !== id);
    setNotes(updatedNotes);
    
    if (activeNote && activeNote.id === id) {
      setActiveNote(null);
      setTitle('');
      setContent('');
      setIsEditing(false);
    }
    
    toast({
      title: "Nota eliminada",
      description: "La nota ha sido eliminada permanentemente",
    });
  };

  const handleSelectNote = (note) => {
    setActiveNote(note);
    setTitle(note.title);
    setContent(note.content);
    setIsEditing(false);
  };

  const handleEditNote = () => {
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    if (activeNote) {
      setTitle(activeNote.title);
      setContent(activeNote.content);
    } else {
      setTitle('');
      setContent('');
    }
    setIsEditing(false);
  };

  const filteredNotes = notes.filter(note => 
    note.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    note.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
  };

  return (
    <div className="h-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Mis Notas</h1>
        <Button onClick={handleNewNote}>
          <Plus className="mr-2 h-4 w-4" /> Nueva Nota
        </Button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
        <input
          type="text"
          placeholder="Buscar notas..."
          className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-colors"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {searchTerm && (
          <button 
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            onClick={() => setSearchTerm('')}
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <h2 className="text-xl font-semibold mb-4">Lista de Notas</h2>
          
          {filteredNotes.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg">
              <p className="text-gray-500">No hay notas disponibles</p>
              {searchTerm && (
                <p className="text-sm text-gray-400 mt-2">Intenta con otra búsqueda</p>
              )}
            </div>
          ) : (
            <motion.div 
              className="space-y-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ staggerChildren: 0.1 }}
            >
              {filteredNotes.map((note) => (
                <motion.div
                  key={note.id}
                  className={`note-card p-4 rounded-lg border cursor-pointer ${
                    activeNote && activeNote.id === note.id 
                      ? 'border-primary bg-primary/5' 
                      : 'hover:border-gray-300 bg-white'
                  }`}
                  onClick={() => handleSelectNote(note)}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium truncate">{note.title}</h3>
                    <button 
                      className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-gray-100"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteNote(note.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 mt-1 truncate">{note.content}</p>
                  <p className="text-xs text-gray-400 mt-2">{formatDate(note.date)}</p>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>

        <div className="md:col-span-2 bg-white rounded-lg border p-6">
          {!activeNote && !isEditing ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
              <div className="bg-gray-100 p-4 rounded-full mb-4">
                <Edit className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium mb-2">No hay nota seleccionada</h3>
              <p className="text-gray-500 mb-6">Selecciona una nota existente o crea una nueva para empezar</p>
              <Button onClick={handleNewNote}>
                <Plus className="mr-2 h-4 w-4" /> Nueva Nota
              </Button>
            </div>
          ) : (
            <>
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Título de la nota"
                  className="w-full text-2xl font-bold border-none focus:outline-none focus:ring-0 p-0 bg-transparent"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  disabled={!isEditing}
                />
                {activeNote && (
                  <p className="text-sm text-gray-400 mt-1">
                    Última actualización: {formatDate(activeNote.date)}
                  </p>
                )}
              </div>
              
              <textarea
                placeholder="Escribe el contenido de tu nota aquí..."
                className="w-full min-h-[300px] border-none focus:outline-none focus:ring-0 p-0 bg-transparent resize-none"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                disabled={!isEditing}
              />
              
              <div className="flex justify-end space-x-3 mt-6">
                {isEditing ? (
                  <>
                    <Button variant="outline" onClick={handleCancelEdit}>
                      Cancelar
                    </Button>
                    <Button onClick={handleSaveNote}>
                      <Save className="mr-2 h-4 w-4" /> Guardar
                    </Button>
                  </>
                ) : (
                  activeNote && (
                    <>
                      <Button variant="outline" onClick={() => handleDeleteNote(activeNote.id)}>
                        <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                      </Button>
                      <Button onClick={handleEditNote}>
                        <Edit className="mr-2 h-4 w-4" /> Editar
                      </Button>
                    </>
                  )
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotesPage;
