
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Clock, Plus, Trash2, Edit, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const SchedulePage = () => {
  const daysOfWeek = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const [schedule, setSchedule] = useState({});
  const [showForm, setShowForm] = useState(false);
  const [editingClass, setEditingClass] = useState(null);
  const [selectedDay, setSelectedDay] = useState('Lunes');
  const [className, setClassName] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [professor, setProfessor] = useState('');
  const { toast } = useToast();

  // Load schedule from localStorage on component mount
  useEffect(() => {
    const savedSchedule = localStorage.getItem('jaiygo-schedule');
    if (savedSchedule) {
      setSchedule(JSON.parse(savedSchedule));
    } else {
      // Initialize empty schedule for each day
      const initialSchedule = {};
      daysOfWeek.forEach(day => {
        initialSchedule[day] = [];
      });
      setSchedule(initialSchedule);
    }
  }, []);

  // Save schedule to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('jaiygo-schedule', JSON.stringify(schedule));
  }, [schedule]);

  const handleAddClass = (e) => {
    e.preventDefault();
    
    if (!className.trim() || !startTime || !endTime) {
      toast({
        title: "Error",
        description: "El nombre de la clase, hora de inicio y fin son obligatorios",
        variant: "destructive",
      });
      return;
    }
    
    // Validate that end time is after start time
    if (startTime >= endTime) {
      toast({
        title: "Error",
        description: "La hora de fin debe ser posterior a la hora de inicio",
        variant: "destructive",
      });
      return;
    }
    
    const newClass = {
      id: editingClass ? editingClass.id : Date.now(),
      name: className.trim(),
      startTime,
      endTime,
      location,
      professor,
    };
    
    if (editingClass) {
      // Update existing class
      const updatedClasses = schedule[selectedDay].map(cls => 
        cls.id === editingClass.id ? newClass : cls
      );
      
      setSchedule({
        ...schedule,
        [selectedDay]: updatedClasses,
      });
      
      toast({
        title: "Clase actualizada",
        description: "La clase ha sido actualizada en tu horario",
      });
    } else {
      // Add new class
      setSchedule({
        ...schedule,
        [selectedDay]: [...(schedule[selectedDay] || []), newClass],
      });
      
      toast({
        title: "Clase añadida",
        description: "La clase ha sido añadida a tu horario",
      });
    }
    
    resetForm();
    setShowForm(false);
    setEditingClass(null);
  };

  const handleEditClass = (cls) => {
    setEditingClass(cls);
    setClassName(cls.name);
    setStartTime(cls.startTime);
    setEndTime(cls.endTime);
    setLocation(cls.location || '');
    setProfessor(cls.professor || '');
    setShowForm(true);
  };

  const handleDeleteClass = (id) => {
    const updatedClasses = schedule[selectedDay].filter(cls => cls.id !== id);
    
    setSchedule({
      ...schedule,
      [selectedDay]: updatedClasses,
    });
    
    toast({
      title: "Clase eliminada",
      description: "La clase ha sido eliminada de tu horario",
    });
  };

  const resetForm = () => {
    setClassName('');
    setStartTime('');
    setEndTime('');
    setLocation('');
    setProfessor('');
  };

  const handleCancel = () => {
    resetForm();
    setShowForm(false);
    setEditingClass(null);
  };

  // Sort classes by start time
  const sortedClasses = [...(schedule[selectedDay] || [])].sort((a, b) => 
    a.startTime.localeCompare(b.startTime)
  );

  // Generate time slots for the schedule view
  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 7; hour <= 22; hour++) {
      slots.push(`${hour.toString().padStart(2, '0')}:00`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  // Check if a class is within a time slot
  const isClassInTimeSlot = (cls, slot) => {
    const slotHour = parseInt(slot.split(':')[0]);
    const slotTime = new Date();
    slotTime.setHours(slotHour, 0, 0, 0);
    
    const startParts = cls.startTime.split(':');
    const startTime = new Date();
    startTime.setHours(parseInt(startParts[0]), parseInt(startParts[1]), 0, 0);
    
    const endParts = cls.endTime.split(':');
    const endTime = new Date();
    endTime.setHours(parseInt(endParts[0]), parseInt(endParts[1]), 0, 0);
    
    return startTime <= slotTime && endTime > slotTime;
  };

  // Get classes for a specific time slot
  const getClassesForTimeSlot = (slot) => {
    return sortedClasses.filter(cls => isClassInTimeSlot(cls, slot));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Mi Horario</h1>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" /> Añadir Clase
        </Button>
      </div>

      {/* Day selector */}
      <div className="flex overflow-x-auto pb-2 space-x-2">
        {daysOfWeek.map((day) => (
          <button
            key={day}
            className={`px-4 py-2 rounded-md whitespace-nowrap transition-colors ${
              selectedDay === day
                ? 'bg-primary text-white'
                : 'bg-white border hover:bg-gray-50'
            }`}
            onClick={() => setSelectedDay(day)}
          >
            {day}
          </button>
        ))}
      </div>

      {showForm ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg border p-6"
        >
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">
              {editingClass ? 'Editar Clase' : 'Añadir Nueva Clase'}
            </h2>
            <button 
              className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
              onClick={handleCancel}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <form onSubmit={handleAddClass} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Día de la semana
              </label>
              <select
                className="w-full p-2 border rounded-md"
                value={selectedDay}
                onChange={(e) => setSelectedDay(e.target.value)}
              >
                {daysOfWeek.map((day) => (
                  <option key={day} value={day}>{day}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nombre de la clase *
              </label>
              <input
                type="text"
                className="w-full p-2 border rounded-md"
                placeholder="Ej: Matemáticas"
                value={className}
                onChange={(e) => setClassName(e.target.value)}
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hora de inicio *
                </label>
                <input
                  type="time"
                  className="w-full p-2 border rounded-md"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hora de fin *
                </label>
                <input
                  type="time"
                  className="w-full p-2 border rounded-md"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ubicación
              </label>
              <input
                type="text"
                className="w-full p-2 border rounded-md"
                placeholder="Ej: Aula 101"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Profesor
              </label>
              <input
                type="text"
                className="w-full p-2 border rounded-md"
                placeholder="Ej: Prof. García"
                value={professor}
                onChange={(e) => setProfessor(e.target.value)}
              />
            </div>
            
            <div className="flex justify-end space-x-3 pt-2">
              <Button type="button" variant="outline" onClick={handleCancel}>
                Cancelar
              </Button>
              <Button type="submit">
                {editingClass ? (
                  <>
                    <Save className="mr-2 h-4 w-4" /> Actualizar
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" /> Añadir
                  </>
                )}
              </Button>
            </div>
          </form>
        </motion.div>
      ) : (
        <div className="bg-white rounded-lg border overflow-hidden">
          <div className="p-4 border-b">
            <h2 className="text-xl font-semibold">Horario para {selectedDay}</h2>
          </div>
          
          {sortedClasses.length === 0 ? (
            <div className="text-center py-10">
              <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No hay clases programadas para este día</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setShowForm(true)}
              >
                <Plus className="mr-2 h-4 w-4" /> Añadir Clase
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              {timeSlots.map((slot) => {
                const classesInSlot = getClassesForTimeSlot(slot);
                if (classesInSlot.length === 0) return null;
                
                return (
                  <div key={slot} className="p-4 hover:bg-gray-50">
                    <div className="flex items-center mb-2">
                      <Clock className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm font-medium text-gray-500">{slot}</span>
                    </div>
                    
                    <div className="space-y-3 pl-6">
                      {classesInSlot.map((cls) => (
                        <motion.div
                          key={cls.id}
                          className="schedule-item p-3 rounded-lg border bg-blue-50 border-blue-200"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{cls.name}</h3>
                              <p className="text-sm text-gray-600 mt-1">
                                {cls.startTime} - {cls.endTime}
                              </p>
                              
                              {(cls.location || cls.professor) && (
                                <div className="mt-2 text-sm text-gray-600">
                                  {cls.location && <p>Ubicación: {cls.location}</p>}
                                  {cls.professor && <p>Profesor: {cls.professor}</p>}
                                </div>
                              )}
                            </div>
                            
                            <div className="flex space-x-1">
                              <button
                                className="text-gray-400 hover:text-blue-600 p-1 rounded-full hover:bg-white"
                                onClick={() => handleEditClass(cls)}
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              <button
                                className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-white"
                                onClick={() => handleDeleteClass(cls.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SchedulePage;
