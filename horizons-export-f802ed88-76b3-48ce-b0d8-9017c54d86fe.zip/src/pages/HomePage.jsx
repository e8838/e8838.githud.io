
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { BookOpen, Calendar, Clock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HomePage = () => {
  const features = [
    {
      icon: <BookOpen className="h-10 w-10 text-primary" />,
      title: 'Apuntes y Notas',
      description: 'Organiza tus apuntes de clase y notas importantes en un solo lugar.',
      link: '/notas',
    },
    {
      icon: <Calendar className="h-10 w-10 text-accent" />,
      title: 'Agenda Personal',
      description: 'Mantén un registro de tus tareas, exámenes y eventos importantes.',
      link: '/agenda',
    },
    {
      icon: <Clock className="h-10 w-10 text-green-500" />,
      title: 'Horarios',
      description: 'Visualiza tu horario escolar y organiza mejor tu tiempo.',
      link: '/horarios',
    },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <div className="space-y-10 py-4">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl gradient-bg text-white p-8 md:p-12">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/30 to-purple-600/30"></div>
        <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
          <motion.h1 
            className="text-4xl md:text-5xl font-bold"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Bienvenido a <span className="text-yellow-300">Jaiy Go</span>
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Tu asistente escolar personal para organizar notas, agenda y horarios
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Button size="lg" asChild>
              <Link to="/notas">
                Comenzar ahora <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </motion.div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -bottom-16 -left-16 w-64 h-64 rounded-full bg-blue-500/20 blur-3xl"></div>
        <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-purple-500/20 blur-3xl"></div>
      </section>

      {/* Features Section */}
      <section>
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-2">Funcionalidades</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Jaiy Go te ofrece todo lo que necesitas para organizar tu vida académica
          </p>
        </div>

        <motion.div 
          className="grid md:grid-cols-3 gap-6"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              className="glass-card rounded-xl p-6 flex flex-col items-center text-center hover:shadow-lg transition-shadow"
              variants={item}
            >
              <div className="mb-4 p-3 rounded-full bg-gray-100">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600 mb-4">{feature.description}</p>
              <Button variant="outline" asChild className="mt-auto">
                <Link to={feature.link}>
                  Explorar <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Quick Start Section */}
      <section className="bg-gray-50 rounded-xl p-8">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold">Inicio Rápido</h2>
          <p className="text-gray-600">Comienza a usar Jaiy Go en segundos</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-3 flex items-center">
              <BookOpen className="h-5 w-5 mr-2 text-primary" /> Crear tu primera nota
            </h3>
            <p className="text-gray-600 mb-4">
              Captura tus ideas, apuntes de clase o información importante en notas organizadas.
            </p>
            <Button variant="outline" asChild>
              <Link to="/notas">Ir a Notas</Link>
            </Button>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-3 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-accent" /> Organizar tu agenda
            </h3>
            <p className="text-gray-600 mb-4">
              Añade eventos importantes, fechas de entrega y exámenes a tu agenda personal.
            </p>
            <Button variant="outline" asChild>
              <Link to="/agenda">Ir a Agenda</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonial/Quote Section */}
      <section className="text-center max-w-3xl mx-auto">
        <blockquote className="text-xl italic text-gray-700">
          "La organización es la clave del éxito académico. Con las herramientas adecuadas, puedes mejorar tu rendimiento y reducir el estrés."
        </blockquote>
        <p className="mt-4 font-medium">- Equipo Jaiy Go</p>
      </section>
    </div>
  );
};

export default HomePage;
